package observe.ex2;

public class Subject {

}
