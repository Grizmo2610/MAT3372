package observe.ex1;

public class BinaryObserver extends Observer {

    @Override
    public void update() {

    }
}
