package observe.ex1;

public class OctalObserver extends Observer {

    @Override
    public void update() {

    }
}
