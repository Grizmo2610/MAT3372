package observe.ex1;

public class HexaObserver extends Observer {
    @Override
    public void update() {

    }
}
