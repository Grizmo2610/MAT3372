package decorator.ex1;

public interface Shape {
    void draw();
}
