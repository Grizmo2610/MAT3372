package decorator.ex1;

public class Cirlce implements Shape {

    @Override
    public void draw() {

    }
}
