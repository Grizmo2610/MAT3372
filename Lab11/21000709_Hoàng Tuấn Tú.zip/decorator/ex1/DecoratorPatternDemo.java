package decorator.ex1;

public class DecoratorPatternDemo {
    public static void main(String[] args) {

    }
}
