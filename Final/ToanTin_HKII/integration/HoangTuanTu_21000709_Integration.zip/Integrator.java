package hus.oop.integration;

public interface Integrator {
    double integrate(Polynomial poly, double lower, double upper);
}
