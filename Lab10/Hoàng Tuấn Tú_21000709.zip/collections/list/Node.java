package collections.list;

public class Node {
    public Object value;
    public Node next = null;

    public Node(Object value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
