package collections.polynomials;

public abstract class AbstractPoly implements Poly{
    public AbstractPoly() {
    }

}
