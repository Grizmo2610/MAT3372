package oop.principles.inheritance;

public class Square extends Rectangle{
    public Square(int size) {
        super(size, size);
    }

}
