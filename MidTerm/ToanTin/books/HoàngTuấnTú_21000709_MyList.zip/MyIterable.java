package oop.books;

public interface MyIterable {
    MyIterator iterator();
}
