package oop.books;

public interface BookComparable {
    int compareTo(Book another);
}
