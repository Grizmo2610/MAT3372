package oop.books;

public interface BookComparator {
    int compare(Book left, Book right);
}
