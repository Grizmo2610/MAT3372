package builder.ex1;

public class Director {
    public void makeSUV(Builder builder){

    }
    public void makeSportCar(Builder builder){
        
    }
}
