package abstractfactory.ex2;

public interface Color {
    void fill();
}
