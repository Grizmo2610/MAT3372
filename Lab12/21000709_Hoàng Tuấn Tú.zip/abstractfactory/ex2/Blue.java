package abstractfactory.ex2;

public class Blue implements Color {
    public void fill() {
        System.out.println("Filling with Blue color");
    }
}