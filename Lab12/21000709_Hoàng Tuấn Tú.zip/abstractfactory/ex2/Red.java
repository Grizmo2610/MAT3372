package abstractfactory.ex2;

public class Red implements Color {
    public void fill() {
        System.out.println("Filling with Red color");
    }
}