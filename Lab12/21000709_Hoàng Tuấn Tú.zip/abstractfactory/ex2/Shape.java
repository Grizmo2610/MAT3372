package abstractfactory.ex2;

public interface Shape {
    void draw();
}
