package abstractfactory.ex1;

public abstract class Button {
    public Button() {
    }
}
