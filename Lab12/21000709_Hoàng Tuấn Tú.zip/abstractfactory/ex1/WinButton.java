package abstractfactory.ex1;

public class WinButton extends Button{
    public WinButton() {
    }
}
