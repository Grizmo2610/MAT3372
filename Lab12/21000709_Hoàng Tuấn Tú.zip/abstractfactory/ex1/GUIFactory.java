package abstractfactory.ex1;

public interface GUIFactory {
    Button createButton();
    CheckBox createCheckBox();
}
