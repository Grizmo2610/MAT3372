package abstractfactory.ex1;

public class MacButton extends Button {
    public MacButton() {
    }
}
