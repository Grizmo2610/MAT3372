package abstractfactory.ex1;

public abstract class CheckBox {
    public CheckBox() {
    }
}
