package abstractfactory.ex1;

public class WinCheckBox extends CheckBox{
    public WinCheckBox() {
    }
}
