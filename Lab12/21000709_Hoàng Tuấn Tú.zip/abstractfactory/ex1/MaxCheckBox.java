package abstractfactory.ex1;

public class MaxCheckBox extends CheckBox {
    public MaxCheckBox() {
    }
}
