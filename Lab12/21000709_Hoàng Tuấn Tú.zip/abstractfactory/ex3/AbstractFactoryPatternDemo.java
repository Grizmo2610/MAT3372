package abstractfactory.ex3;

public class AbstractFactoryPatternDemo {
    public static void main(String[] args) {
        FactoryProducer producer = new FactoryProducer();
    }
}
