package abstractfactory.ex3;

public abstract class AbstractFactory{
    abstract Shape getShape();

}
