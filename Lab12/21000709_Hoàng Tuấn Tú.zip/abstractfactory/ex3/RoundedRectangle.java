package abstractfactory.ex3;

public class RoundedRectangle extends Rectangle implements Shape{
    @Override
    public void draw(){

    }
}
