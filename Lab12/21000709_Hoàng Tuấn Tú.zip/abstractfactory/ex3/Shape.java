package abstractfactory.ex3;

public interface Shape {
    void draw();
}
