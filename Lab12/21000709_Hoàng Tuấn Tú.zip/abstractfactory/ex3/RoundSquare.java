package abstractfactory.ex3;

public class RoundSquare extends Square implements Shape{
    @Override
    public void draw() {

    }
}
