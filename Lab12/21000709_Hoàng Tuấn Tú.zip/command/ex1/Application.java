package command.ex1;

public class Application {
    public Editor[] editors;
}
