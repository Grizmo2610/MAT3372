package command.ex1;

public class Command {

}
