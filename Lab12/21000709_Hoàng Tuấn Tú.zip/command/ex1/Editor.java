package command.ex1;

public class Editor {
    String text;
    public void getSelection(){

    }

    public void deleteSelection(){

    }

    public void replaceSelection(String text){
        this.text = text;
    }
}
