package Iterator.ex1;

public class IteratorPatternExample {
    public static void main(String[] args) {

    }
}
