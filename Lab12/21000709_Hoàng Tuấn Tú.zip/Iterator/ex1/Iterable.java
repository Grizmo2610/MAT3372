package Iterator.ex1;

public interface Iterable {
    Iterator getIterator();
}
