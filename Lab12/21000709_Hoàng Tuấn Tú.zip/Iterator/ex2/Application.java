package Iterator.ex2;

public class Application {
    private SocialSpammer spammer;
    private SocialNetwork network;
    public void sendSpamToFriends(Profile profile){

    }

    public void sendSpamToCoworkers(Profile profile){

    }

}
