package Iterator.ex2;

public class SocialSpammer {

}
