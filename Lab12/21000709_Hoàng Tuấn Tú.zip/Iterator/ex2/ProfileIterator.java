package Iterator.ex2;

public interface ProfileIterator {
    Profile getNext();
    boolean hasNext();
}
