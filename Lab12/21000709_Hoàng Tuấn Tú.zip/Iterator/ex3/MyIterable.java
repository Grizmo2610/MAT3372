package Iterator.ex3;

public interface MyIterable {
    MyIterator iterator();
}
