package bridge.ex1;

public interface OperatingSystem {
    void startup();
    void loadUrl(String url);
}
