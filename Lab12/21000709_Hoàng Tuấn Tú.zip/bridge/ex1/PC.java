package bridge.ex1;

public class PC extends Computer{
}
